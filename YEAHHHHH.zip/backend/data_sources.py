# Connects to APIs: CoinGecko, DexScreener, Yahoo Finance, Capitol Trades, etc.
