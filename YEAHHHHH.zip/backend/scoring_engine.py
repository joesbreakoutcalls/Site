# Scoring logic including politician trade data
