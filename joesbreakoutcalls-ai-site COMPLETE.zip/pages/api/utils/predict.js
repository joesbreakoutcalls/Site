export function scoreAsset(asset) {
  let volatilityFactor = Math.abs(asset.change || 0);
  let volumeFactor = Math.log10(asset.volume || 1);
  let momentum = (asset.change || 0) > 0 ? 1 : -1;
  return (volatilityFactor * volumeFactor * momentum);
}
