# 🚀 Deploying Breakout Predictor to Railway

## Step 1: Create a Railway Project
1. Go to https://railway.app
2. Sign in and click **"New Project"**
3. Choose **"Deploy from GitHub Repo"** or **"Deploy from Template"**

## Step 2: Upload Your Code
1. Upload the contents of this ZIP as your repo or use Railway’s CLI to deploy directly
2. Add environment variables in Railway dashboard:
   - API_KEY (your CoinGecko, Yahoo, DexScreener keys)
   - TELEGRAM_WEBHOOK
   - BASIC_AUTH_USER
   - BASIC_AUTH_PASS

## Step 3: Deploy!
1. Railway will auto-build your frontend/backend
2. Once live, visit your private Railway URL
3. Login with:
   - Username: JoeIsAwesome
   - Password: ClemsonTigers

Your app auto-refreshes every 2 minutes, alerts on breakout changes, and tracks political trades in real-time.
