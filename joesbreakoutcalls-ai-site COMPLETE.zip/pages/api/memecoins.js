import { scoreAsset } from './utils/predict';

export default async function handler(req, res) {
  const mockData = [
    { name: 'MEMECOINS_1', change: 5, volume: 5000000 },
    { name: 'MEMECOINS_2', change: 7, volume: 8000000 },
    { name: 'MEMECOINS_3', change: -2, volume: 3000000 },
  ];
  const scored = mockData.map(item => ({
    ...item,
    score: scoreAsset(item),
    reason: `Mock volatility memecoins | Chg: ${item.change}%, Vol: ${item.volume}`
  }));
  const top10 = scored.sort((a, b) => b.score - a.score);
  res.status(200).json(top10);
}
