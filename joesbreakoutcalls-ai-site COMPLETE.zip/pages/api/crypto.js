import { scoreAsset } from './utils/predict';

export default async function handler(req, res) {
  try {
    const resp = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd');
    const coins = await resp.json();
    const scored = coins.map(c => ({
      name: c.name,
      symbol: c.symbol,
      price: c.current_price,
      change: c.price_change_percentage_24h,
      volume: c.total_volume,
      score: scoreAsset({ change: c.price_change_percentage_24h, volume: c.total_volume }),
      reason: `Vol: $${c.total_volume}, Chg: ${c.price_change_percentage_24h}%`,
    }));
    const top10 = scored.sort((a, b) => b.score - a.score).slice(0, 10);
    res.status(200).json(top10);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching crypto data' });
  }
}
