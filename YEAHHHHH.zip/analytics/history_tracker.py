# Logs historical predictions
