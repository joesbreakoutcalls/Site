# Sends Discord alerts
